import styled from 'styled-components'

export const FormConciliarPagarStyled = styled.div`
height: 610px;

.main-container {
  display: flex;
}

.form-valorResto {
  padding: 0px 12px 0px 0px;
}
.form-natureza {
  margin-left: 18px
}
`
