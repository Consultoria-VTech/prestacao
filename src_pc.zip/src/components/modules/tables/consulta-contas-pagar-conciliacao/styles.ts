import styled from 'styled-components'

export const MainIcons = styled.span`
	.btn-edit {
		height: 50px;
	}

`