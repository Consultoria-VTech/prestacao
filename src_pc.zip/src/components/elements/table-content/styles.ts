import styled from 'styled-components'

export const TableContentStyled = styled.div`
  flex: 1;
  overflow: hidden;

  .scroll-table {
    height: 100%;
  }
`
