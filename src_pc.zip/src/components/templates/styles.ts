import styled from 'styled-components'

export const TemplateDefaultStyled = styled.div`
  padding: 1rem ${props => props.theme.padding.lg};
`
